# ShopSwift - E-commerce Platform

## Project Overview
ShopSwift is a full-stack e-commerce application for Bin Dawood, a wholesale & retail supplier of kitchenware, household items, and restaurant supplies. The application supports dual pricing (wholesale/retail), cart management, and inquiry handling.

## Technology Stack
- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Express.js + TypeScript  
- **Database**: PostgreSQL with Drizzle ORM
- **UI Components**: Radix UI + Tailwind CSS + shadcn/ui
- **State Management**: React Query + Context API
- **Build System**: Vite + ESBuild

## Project Structure
```
ShopSwift/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # UI components
│   │   ├── pages/         # Page components  
│   │   ├── contexts/      # React contexts
│   │   ├── lib/           # Utilities
│   │   └── data/          # Static data
├── server/                # Express backend
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   ├── storage.ts        # Data storage layer
│   └── vite.ts           # Vite integration
├── shared/                # Shared types/schemas
└── dist/                 # Production build output
```

## Features
- **Dual Pricing System**: Separate retail and wholesale pricing
- **Product Catalog**: Categories, search, filtering
- **Shopping Cart**: Add, update, remove items with session persistence
- **Customer Types**: Toggle between retail/wholesale views
- **Inquiry System**: Contact forms for customer inquiries
- **Mobile Responsive**: Works on all device sizes
- **Real-time Updates**: Hot reloading in development

## Development Setup

### Dependencies
- Node.js 20+ 
- PostgreSQL database (optional - falls back to in-memory storage)

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (optional)
- `PORT`: Server port (defaults to 5000)

### Development Commands
```bash
npm install          # Install dependencies
npm run dev         # Start development server
npm run build       # Build for production  
npm start           # Start production server
npm run db:push     # Push database schema
```

## Database
The application uses PostgreSQL with Drizzle ORM. Schema includes:
- Categories (kitchenware, cookware, etc.)
- Products (with dual pricing)
- Cart items (session-based)
- Inquiries (customer messages)

**Fallback**: If no database is configured, the app uses in-memory storage with sample data.

## Recent Changes
- **2024-09-21**: Fixed React Query client bug causing `[object Object]` API requests
- **2024-09-21**: Configured Vite for Replit proxy environment  
- **2024-09-21**: Set up development workflow and deployment configuration
- **2024-09-21**: Verified all API endpoints working correctly

## Deployment
Configured for Replit autoscale deployment:
- Build: `npm run build`
- Start: `npm start`
- Port: 5000 (required for Replit)

## User Preferences
- Uses modern React patterns with TypeScript
- Follows component-based architecture
- Implements proper error handling and loading states
- Mobile-first responsive design approach