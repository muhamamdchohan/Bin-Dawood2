// This file provides sample product data for the Bin Dawood e-commerce application
// Data is structured to match the product schema and support both wholesale/retail pricing

export const sampleProducts = [
  // Kitchenware Category
  {
    id: "prod-1",
    name: "Professional Stainless Steel Cookware Set",
    slug: "professional-cookware-set",
    description: "Premium 12-piece stainless steel cookware set featuring professional-grade construction with tri-ply base for even heat distribution. Perfect for commercial kitchens and serious home cooks. Includes saucepans, stockpot, frying pans, and steamer insert with ergonomic handles.",
    shortDescription: "12-piece stainless steel professional set",
    imageUrl: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-1",
    retailPrice: "299.99",
    wholesalePrice: "249.99",
    moq: 10,
    inStock: true,
    stockQuantity: 100,
    featured: true,
    specifications: JSON.stringify({
      material: "18/10 Stainless Steel",
      pieces: 12,
      dishwasherSafe: true,
      ovenSafe: "Up to 500°F",
      warranty: "5 years",
      weight: "15.5 lbs"
    }),
    createdAt: new Date(),
  },
  {
    id: "prod-2",
    name: "Commercial Grade Pressure Cooker",
    slug: "commercial-pressure-cooker",
    description: "Heavy-duty 8-quart pressure cooker designed for high-volume cooking in restaurants and commercial kitchens. Features multiple safety mechanisms and precise pressure control for consistent results.",
    shortDescription: "8-quart commercial pressure cooker",
    imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-1",
    retailPrice: "189.99",
    wholesalePrice: "149.99",
    moq: 6,
    inStock: true,
    stockQuantity: 75,
    featured: false,
    specifications: JSON.stringify({
      capacity: "8 quarts",
      material: "Aluminum with Steel Base",
      safetyFeatures: ["Pressure Release Valve", "Locking Lid", "Steam Gauge"],
      warranty: "3 years"
    }),
    createdAt: new Date(),
  },

  // Non-stick Cookware Category
  {
    id: "prod-3",
    name: "Premium Ceramic Non-Stick Pan Set",
    slug: "premium-non-stick-pan-set",
    description: "Professional-grade ceramic-coated non-stick frying pan set featuring superior heat retention and PTFE-free cooking surface. Perfect for healthy cooking with minimal oil requirements.",
    shortDescription: "3-piece ceramic non-stick pan set",
    imageUrl: "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-2",
    retailPrice: "129.99",
    wholesalePrice: "99.99",
    moq: 12,
    inStock: true,
    stockQuantity: 120,
    featured: true,
    specifications: JSON.stringify({
      sizes: ["8 inch", "10 inch", "12 inch"],
      coating: "Ceramic Non-Stick",
      handleType: "Stay-Cool Silicone",
      ovenSafe: "Up to 400°F",
      warranty: "2 years"
    }),
    createdAt: new Date(),
  },
  {
    id: "prod-4",
    name: "Professional Non-Stick Griddle",
    slug: "professional-non-stick-griddle",
    description: "Large 12-inch professional griddle with premium non-stick coating, ideal for pancakes, eggs, and multiple portion cooking in commercial settings.",
    shortDescription: "12-inch professional griddle",
    imageUrl: "https://pixabay.com/get/g22f7501dbb4029a48162db7856bb727b9469484e51cd46f3cb991b3a2684f39d72ad5c482b6e8081992d2bf0113a842b13aa93593ccf3a29a25064b1c7300397_1280.jpg",
    categoryId: "cat-2",
    retailPrice: "89.99",
    wholesalePrice: "69.99",
    moq: 20,
    inStock: true,
    stockQuantity: 80,
    featured: true,
    specifications: JSON.stringify({
      size: "12 inch",
      material: "Aluminum with Non-Stick Coating",
      thickness: "3mm base",
      warranty: "18 months"
    }),
    createdAt: new Date(),
  },

  // Dinner Sets & Crockery Category
  {
    id: "prod-5",
    name: "Elegant Porcelain Dinner Set",
    slug: "elegant-porcelain-dinner-set",
    description: "Exquisite 24-piece porcelain dinner set featuring classic white design with gold trim. Perfect for fine dining restaurants, hotels, and special occasions. Includes dinner plates, salad plates, bowls, and serving pieces.",
    shortDescription: "24-piece elegant porcelain collection",
    imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-3",
    retailPrice: "199.99",
    wholesalePrice: "159.99",
    moq: 6,
    inStock: true,
    stockQuantity: 60,
    featured: true,
    specifications: JSON.stringify({
      material: "Fine Porcelain",
      pieces: 24,
      serves: 6,
      microwaveSafe: true,
      dishwasherSafe: true,
      design: "Classic White with Gold Trim",
      warranty: "3 years"
    }),
    createdAt: new Date(),
  },
  {
    id: "prod-6",
    name: "Commercial Stoneware Bowl Set",
    slug: "commercial-stoneware-bowl-set",
    description: "Durable stoneware bowl set designed for high-volume restaurant use. Chip-resistant and stackable for efficient storage.",
    shortDescription: "12-piece commercial stoneware bowls",
    imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-3",
    retailPrice: "149.99",
    wholesalePrice: "119.99",
    moq: 8,
    inStock: true,
    stockQuantity: 45,
    featured: false,
    specifications: JSON.stringify({
      material: "High-Fire Stoneware",
      pieces: 12,
      sizes: ["Small (6oz)", "Medium (12oz)", "Large (18oz)"],
      microwave: true,
      oven: true,
      warranty: "2 years"
    }),
    createdAt: new Date(),
  },

  // Cutlery Category
  {
    id: "prod-7",
    name: "Professional Chef Knife Set",
    slug: "professional-chef-knife-set",
    description: "Premium 6-piece German steel chef knife set with precision-forged blades and ergonomic handles. Includes paring knife, utility knife, chef's knife, bread knife, carving knife, and wooden storage block.",
    shortDescription: "6-piece German steel knife set",
    imageUrl: "https://images.unsplash.com/photo-1618220048045-10a6dbdf83e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-4",
    retailPrice: "149.99",
    wholesalePrice: "119.99",
    moq: 12,
    inStock: true,
    stockQuantity: 50,
    featured: true,
    specifications: JSON.stringify({
      material: "German High-Carbon Steel",
      pieces: 6,
      handleMaterial: "Ergonomic Polymer",
      blockIncluded: true,
      sharpening: "Hand-honed edges",
      warranty: "Lifetime"
    }),
    createdAt: new Date(),
  },
  {
    id: "prod-8",
    name: "Commercial Cutlery Set",
    slug: "commercial-cutlery-set",
    description: "Heavy-duty 48-piece cutlery set designed for restaurant and hotel use. Includes knives, forks, and spoons in commercial-grade stainless steel.",
    shortDescription: "48-piece commercial cutlery set",
    imageUrl: "https://images.unsplash.com/photo-1618220048045-10a6dbdf83e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-4",
    retailPrice: "89.99",
    wholesalePrice: "69.99",
    moq: 25,
    inStock: true,
    stockQuantity: 120,
    featured: false,
    specifications: JSON.stringify({
      pieces: 48,
      material: "18/0 Stainless Steel",
      finish: "Mirror Polish",
      dishwasher: true,
      warranty: "5 years commercial use"
    }),
    createdAt: new Date(),
  },

  // Household Items Category
  {
    id: "prod-9",
    name: "Premium Storage Container Set",
    slug: "premium-storage-container-set",
    description: "Airtight food storage container set with leak-proof lids. Perfect for pantry organization and food preservation in commercial and home kitchens.",
    shortDescription: "10-piece airtight storage set",
    imageUrl: "https://pixabay.com/get/gbf7c609cdb0ed428da18e75d553bc3ca8a58022196763d2af631f8b6639dc85cb57fa621ff981a2970cd79f35c8bff7b15422fab589300cf2b4a6a72845baa07_1280.jpg",
    categoryId: "cat-5",
    retailPrice: "79.99",
    wholesalePrice: "59.99",
    moq: 15,
    inStock: true,
    stockQuantity: 90,
    featured: false,
    specifications: JSON.stringify({
      pieces: 10,
      material: "BPA-Free Plastic",
      sizes: "Various (0.5L to 4L)",
      features: ["Airtight Seal", "Stackable", "Clear View"],
      warranty: "2 years"
    }),
    createdAt: new Date(),
  },
  {
    id: "prod-10",
    name: "Professional Kitchen Utensil Set",
    slug: "professional-kitchen-utensil-set",
    description: "Comprehensive 15-piece kitchen utensil set including spatulas, spoons, tongs, and specialty tools for professional cooking environments.",
    shortDescription: "15-piece professional utensil set",
    imageUrl: "https://pixabay.com/get/gbf7c609cdb0ed428da18e75d553bc3ca8a58022196763d2af631f8b6639dc85cb57fa621ff981a2970cd79f35c8bff7b15422fab589300cf2b4a6a72845baa07_1280.jpg",
    categoryId: "cat-5",
    retailPrice: "99.99",
    wholesalePrice: "79.99",
    moq: 10,
    inStock: true,
    stockQuantity: 65,
    featured: true,
    specifications: JSON.stringify({
      pieces: 15,
      material: "Silicone and Stainless Steel",
      heatResistant: "Up to 450°F",
      dishwasher: true,
      warranty: "3 years"
    }),
    createdAt: new Date(),
  },

  // Plastic Products Category
  {
    id: "prod-11",
    name: "Commercial Food Storage Containers",
    slug: "commercial-food-storage-containers",
    description: "Heavy-duty food storage containers designed for commercial kitchen use. Features secure lids and stackable design for efficient storage.",
    shortDescription: "8-piece commercial storage containers",
    imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-6",
    retailPrice: "69.99",
    wholesalePrice: "54.99",
    moq: 20,
    inStock: true,
    stockQuantity: 110,
    featured: false,
    specifications: JSON.stringify({
      pieces: 8,
      material: "Food-Grade Polypropylene",
      sizes: "1L, 2L, 4L, 6L",
      temperature: "-20°F to 200°F",
      warranty: "1 year commercial use"
    }),
    createdAt: new Date(),
  },
  {
    id: "prod-12",
    name: "Multi-Purpose Cutting Boards",
    slug: "multi-purpose-cutting-boards",
    description: "Color-coded cutting board set to prevent cross-contamination. Essential for HACCP compliance in commercial kitchens.",
    shortDescription: "6-piece color-coded cutting boards",
    imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-6",
    retailPrice: "59.99",
    wholesalePrice: "44.99",
    moq: 18,
    inStock: true,
    stockQuantity: 85,
    featured: false,
    specifications: JSON.stringify({
      pieces: 6,
      material: "High-Density Polyethylene",
      colors: ["Red", "Yellow", "Green", "Blue", "White", "Brown"],
      size: "12\" x 18\" x 0.5\"",
      dishwasher: true,
      warranty: "2 years"
    }),
    createdAt: new Date(),
  },

  // Restaurant Ware Category
  {
    id: "prod-13",
    name: "Commercial Serving Tray Set",
    slug: "commercial-serving-tray-set",
    description: "Professional serving trays designed for high-volume restaurant service. Non-slip surface and ergonomic design for server comfort.",
    shortDescription: "5-piece commercial serving trays",
    imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-7",
    retailPrice: "119.99",
    wholesalePrice: "94.99",
    moq: 8,
    inStock: true,
    stockQuantity: 40,
    featured: false,
    specifications: JSON.stringify({
      pieces: 5,
      sizes: ["12\"", "14\"", "16\"", "18\"", "20\""],
      material: "Fiberglass",
      surface: "Non-Slip Textured",
      dishwasher: true,
      warranty: "3 years commercial"
    }),
    createdAt: new Date(),
  },
  {
    id: "prod-14",
    name: "Industrial Kitchen Scale",
    slug: "industrial-kitchen-scale",
    description: "Heavy-duty digital scale for commercial kitchens with high weight capacity and precise measurements for portion control and recipe consistency.",
    shortDescription: "Digital commercial kitchen scale",
    imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-7",
    retailPrice: "199.99",
    wholesalePrice: "159.99",
    moq: 4,
    inStock: true,
    stockQuantity: 25,
    featured: true,
    specifications: JSON.stringify({
      capacity: "66 lbs / 30 kg",
      accuracy: "0.1 oz / 1g",
      display: "LCD Digital",
      platform: "Stainless Steel",
      power: "AC Adapter or Battery",
      warranty: "2 years"
    }),
    createdAt: new Date(),
  },

  // Hotel Ware Category
  {
    id: "prod-15",
    name: "Luxury Buffet Serving Set",
    slug: "luxury-buffet-serving-set",
    description: "Elegant buffet serving collection designed for high-end hotels and catering events. Includes chafing dishes, serving utensils, and presentation pieces.",
    shortDescription: "12-piece luxury buffet collection",
    imageUrl: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-8",
    retailPrice: "499.99",
    wholesalePrice: "399.99",
    moq: 3,
    inStock: true,
    stockQuantity: 20,
    featured: true,
    specifications: JSON.stringify({
      pieces: 12,
      material: "Stainless Steel with Gold Accents",
      includes: ["Chafing Dishes", "Serving Spoons", "Ladles", "Tongs"],
      fuelType: "Sterno Compatible",
      warranty: "5 years"
    }),
    createdAt: new Date(),
  },
  {
    id: "prod-16",
    name: "Hotel Room Service Set",
    slug: "hotel-room-service-set",
    description: "Complete room service dining set with elegant presentation pieces designed for luxury hotel guest experiences.",
    shortDescription: "Premium room service collection",
    imageUrl: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    categoryId: "cat-8",
    retailPrice: "299.99",
    wholesalePrice: "239.99",
    moq: 6,
    inStock: true,
    stockQuantity: 30,
    featured: false,
    specifications: JSON.stringify({
      pieces: 18,
      material: "Fine Bone China",
      includes: ["Dinner Plates", "Coffee Cups", "Saucers", "Serving Bowls"],
      design: "Classic White with Silver Rim",
      dishwasher: true,
      warranty: "3 years"
    }),
    createdAt: new Date(),
  }
];

// Additional utility functions for product management
export const getProductsByCategory = (categorySlug: string) => {
  return sampleProducts.filter(product => {
    // This would need to be matched against actual category data
    const categoryMap: { [key: string]: string } = {
      'kitchenware': 'cat-1',
      'non-stick-cookware': 'cat-2',
      'dinner-sets': 'cat-3',
      'cutlery': 'cat-4',
      'household-items': 'cat-5',
      'plastic-products': 'cat-6',
      'restaurant-ware': 'cat-7',
      'hotel-ware': 'cat-8',
    };
    return product.categoryId === categoryMap[categorySlug];
  });
};

export const getFeaturedProducts = () => {
  return sampleProducts.filter(product => product.featured);
};

export const searchProducts = (query: string) => {
  const searchTerm = query.toLowerCase();
  return sampleProducts.filter(product =>
    product.name.toLowerCase().includes(searchTerm) ||
    product.description.toLowerCase().includes(searchTerm) ||
    product.shortDescription.toLowerCase().includes(searchTerm)
  );
};
