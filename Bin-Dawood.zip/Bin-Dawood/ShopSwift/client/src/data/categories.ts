// This file provides sample category data for the Bin Dawood e-commerce application
// Data is structured to match the category schema and provides comprehensive product categorization

export const sampleCategories = [
  {
    id: "cat-1",
    name: "Kitchenware",
    slug: "kitchenware",
    description: "Professional pots, pans, pressure cookers, and essential cooking equipment",
    imageUrl: "https://pixabay.com/get/g6727ac423b10d641731f73b4a627cba3ba979ffde6d17b3b8ff4f6698645d3140b6cbd62215fc6cdb2eff40be7db02d0c370a51141542d262b51b72cd0239028_1280.jpg",
    productCount: 500,
  },
  {
    id: "cat-2",
    name: "Non-stick Cookware",
    slug: "non-stick-cookware",
    description: "Premium non-stick frying pans, griddles, and ceramic-coated cookware sets",
    imageUrl: "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
    productCount: 300,
  },
  {
    id: "cat-3",
    name: "Dinner Sets & Crockery",
    slug: "dinner-sets",
    description: "Elegant dinner sets, fine china, serving bowls, and porcelain collections",
    imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
    productCount: 400,
  },
  {
    id: "cat-4",
    name: "Cutlery",
    slug: "cutlery",
    description: "Professional chef knives, kitchen knife sets, and commercial cutlery",
    imageUrl: "https://images.unsplash.com/photo-1618220048045-10a6dbdf83e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
    productCount: 250,
  },
  {
    id: "cat-5",
    name: "Household Items",
    slug: "household-items",
    description: "Kitchen storage solutions, utensils, cleaning supplies, and accessories",
    imageUrl: "https://pixabay.com/get/gbf7c609cdb0ed428da18e75d553bc3ca8a58022196763d2af631f8b6639dc85cb57fa621ff981a2970cd79f35c8bff7b15422fab589300cf2b4a6a72845baa07_1280.jpg",
    productCount: 600,
  },
  {
    id: "cat-6",
    name: "Plastic Products",
    slug: "plastic-products",
    description: "Food-safe storage containers, cutting boards, and plastic kitchen tools",
    imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
    productCount: 350,
  },
  {
    id: "cat-7",
    name: "Restaurant Ware",
    slug: "restaurant-ware",
    description: "Commercial kitchen equipment, serving trays, and restaurant supplies",
    imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
    productCount: 200,
  },
  {
    id: "cat-8",
    name: "Hotel Ware",
    slug: "hotel-ware",
    description: "Luxury buffet equipment, room service sets, and professional tableware",
    imageUrl: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
    productCount: 180,
  },
];

// Utility functions for category management
export const getCategoryBySlug = (slug: string) => {
  return sampleCategories.find(category => category.slug === slug);
};

export const getCategoryById = (id: string) => {
  return sampleCategories.find(category => category.id === id);
};

export const getAllCategories = () => {
  return sampleCategories;
};

// Category hierarchy and relationships
export const categoryHierarchy = {
  primary: [
    'kitchenware',
    'non-stick-cookware', 
    'dinner-sets',
    'cutlery'
  ],
  secondary: [
    'household-items',
    'plastic-products'
  ],
  commercial: [
    'restaurant-ware',
    'hotel-ware'
  ]
};

// Category-specific filters and attributes
export const categoryFilters = {
  'kitchenware': {
    materials: ['Stainless Steel', 'Aluminum', 'Cast Iron', 'Carbon Steel'],
    sizes: ['Small', 'Medium', 'Large', 'Extra Large'],
    types: ['Pots', 'Pans', 'Pressure Cookers', 'Stockpots']
  },
  'non-stick-cookware': {
    coatings: ['Ceramic', 'PTFE', 'Hard-Anodized', 'Diamond'],
    sizes: ['8 inch', '10 inch', '12 inch', '14 inch'],
    types: ['Frying Pans', 'Griddles', 'Woks', 'Sets']
  },
  'dinner-sets': {
    materials: ['Porcelain', 'Bone China', 'Stoneware', 'Melamine'],
    pieces: ['12-piece', '16-piece', '24-piece', '48-piece'],
    styles: ['Classic', 'Modern', 'Traditional', 'Contemporary']
  },
  'cutlery': {
    materials: ['German Steel', 'Japanese Steel', 'Stainless Steel', 'Carbon Steel'],
    types: ['Chef Knives', 'Paring Knives', 'Bread Knives', 'Utility Knives'],
    sets: ['3-piece', '5-piece', '7-piece', '15-piece']
  },
  'household-items': {
    types: ['Storage', 'Utensils', 'Cleaning', 'Accessories'],
    materials: ['Plastic', 'Silicone', 'Stainless Steel', 'Bamboo'],
    functions: ['Organization', 'Food Prep', 'Cleaning', 'Serving']
  },
  'plastic-products': {
    materials: ['BPA-Free Plastic', 'Food-Grade PP', 'Melamine', 'Acrylic'],
    types: ['Containers', 'Cutting Boards', 'Serving Ware', 'Tools'],
    sizes: ['Small', 'Medium', 'Large', 'Bulk']
  },
  'restaurant-ware': {
    types: ['Serving Equipment', 'Preparation Tools', 'Storage Solutions', 'Cleaning Supplies'],
    capacity: ['Light Duty', 'Medium Duty', 'Heavy Duty', 'Industrial'],
    compliance: ['NSF Certified', 'FDA Approved', 'Commercial Grade']
  },
  'hotel-ware': {
    styles: ['Luxury', 'Contemporary', 'Classic', 'Boutique'],
    applications: ['Room Service', 'Buffet', 'Banquet', 'Restaurant'],
    materials: ['Fine China', 'Stainless Steel', 'Silver Plated', 'Crystal']
  }
};

// SEO and marketing data for categories
export const categorySEO = {
  'kitchenware': {
    metaTitle: 'Professional Kitchenware - Pots, Pans & Cooking Equipment | Bin Dawood',
    metaDescription: 'Shop premium professional kitchenware including stainless steel cookware, pressure cookers, and commercial-grade pots and pans. Wholesale and retail pricing available.',
    keywords: ['professional kitchenware', 'commercial cookware', 'stainless steel pots', 'pressure cookers', 'restaurant equipment']
  },
  'non-stick-cookware': {
    metaTitle: 'Non-Stick Cookware - Ceramic & PTFE Coated Pans | Bin Dawood',
    metaDescription: 'Discover premium non-stick cookware including ceramic-coated pans, professional griddles, and complete non-stick sets for commercial kitchens.',
    keywords: ['non-stick cookware', 'ceramic pans', 'professional griddles', 'PTFE cookware', 'commercial non-stick']
  },
  'dinner-sets': {
    metaTitle: 'Elegant Dinner Sets & Fine China - Porcelain Tableware | Bin Dawood',
    metaDescription: 'Explore our collection of elegant dinner sets, fine porcelain, and professional tableware perfect for restaurants, hotels, and fine dining.',
    keywords: ['dinner sets', 'fine china', 'porcelain tableware', 'restaurant plates', 'hotel dinnerware']
  },
  'cutlery': {
    metaTitle: 'Professional Cutlery & Chef Knives - German Steel Knives | Bin Dawood',
    metaDescription: 'Professional chef knives and commercial cutlery sets made from premium German steel. Perfect for restaurants and professional kitchens.',
    keywords: ['chef knives', 'professional cutlery', 'German steel knives', 'commercial knives', 'kitchen knife sets']
  },
  'household-items': {
    metaTitle: 'Kitchen Storage & Household Items - Organization Solutions | Bin Dawood',
    metaDescription: 'Kitchen storage solutions, utensils, and household items for efficient kitchen organization and food preparation.',
    keywords: ['kitchen storage', 'household items', 'kitchen utensils', 'food storage', 'kitchen organization']
  },
  'plastic-products': {
    metaTitle: 'Food-Safe Plastic Products - Storage Containers & Tools | Bin Dawood',
    metaDescription: 'BPA-free plastic products including food storage containers, cutting boards, and kitchen tools for commercial and home use.',
    keywords: ['plastic storage containers', 'BPA-free kitchenware', 'food-safe plastic', 'commercial plastic products']
  },
  'restaurant-ware': {
    metaTitle: 'Restaurant Equipment & Commercial Kitchen Supplies | Bin Dawood',
    metaDescription: 'Commercial restaurant equipment and kitchen supplies for professional foodservice operations. NSF certified and commercial-grade products.',
    keywords: ['restaurant equipment', 'commercial kitchen supplies', 'foodservice equipment', 'NSF certified', 'commercial cookware']
  },
  'hotel-ware': {
    metaTitle: 'Luxury Hotel Tableware & Buffet Equipment | Bin Dawood',
    metaDescription: 'Premium hotel tableware, buffet equipment, and luxury serving pieces for high-end hospitality operations and catering.',
    keywords: ['hotel tableware', 'luxury dinnerware', 'buffet equipment', 'hospitality supplies', 'catering equipment']
  }
};
