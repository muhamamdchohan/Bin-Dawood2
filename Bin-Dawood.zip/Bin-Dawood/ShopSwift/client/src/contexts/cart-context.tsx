import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import type { CartItem, Product } from '@shared/schema';
import { useCustomer } from './customer-context';

interface CartItemWithProduct extends CartItem {
  product?: Product;
}

interface CartContextType {
  items: CartItemWithProduct[];
  totalItems: number;
  isLoading: boolean;
  addItem: (productId: string, quantity?: number) => void;
  updateItem: (id: string, quantity: number) => void;
  removeItem: (id: string) => void;
  clearCart: () => void;
  getTotalPrice: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}

interface CartProviderProps {
  children: ReactNode;
}

export function CartProvider({ children }: CartProviderProps) {
  const [sessionId] = useState(() => {
    // Get or create session ID
    let id = localStorage.getItem('cart-session-id');
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem('cart-session-id', id);
    }
    return id;
  });

  const { customerType } = useCustomer();
  const queryClient = useQueryClient();

  const { data: items = [], isLoading } = useQuery({
    queryKey: ['/api/cart', { sessionId }],
    queryFn: async () => {
      const response = await fetch(`/api/cart?sessionId=${sessionId}`);
      if (!response.ok) throw new Error('Failed to fetch cart');
      return response.json() as Promise<CartItemWithProduct[]>;
    },
  });

  const addItemMutation = useMutation({
    mutationFn: async ({ productId, quantity = 1 }: { productId: string; quantity?: number }) => {
      const response = await apiRequest('POST', '/api/cart', {
        productId,
        quantity,
        customerType,
        sessionId,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
  });

  const updateItemMutation = useMutation({
    mutationFn: async ({ id, quantity }: { id: string; quantity: number }) => {
      const response = await apiRequest('PATCH', `/api/cart/${id}`, { quantity });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
  });

  const removeItemMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('DELETE', `/api/cart/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
  });

  const clearCartMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('DELETE', `/api/cart?sessionId=${sessionId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
  });

  const addItem = (productId: string, quantity = 1) => {
    addItemMutation.mutate({ productId, quantity });
  };

  const updateItem = (id: string, quantity: number) => {
    updateItemMutation.mutate({ id, quantity });
  };

  const removeItem = (id: string) => {
    removeItemMutation.mutate(id);
  };

  const clearCart = () => {
    clearCartMutation.mutate();
  };

  const getTotalPrice = () => {
    return items.reduce((total, item) => {
      if (!item.product) return total;
      const price = customerType === 'wholesale' 
        ? parseFloat(item.product.wholesalePrice) 
        : parseFloat(item.product.retailPrice);
      return total + (price * item.quantity);
    }, 0);
  };

  const totalItems = items.reduce((total, item) => total + item.quantity, 0);

  return (
    <CartContext.Provider value={{
      items,
      totalItems,
      isLoading,
      addItem,
      updateItem,
      removeItem,
      clearCart,
      getTotalPrice,
    }}>
      {children}
    </CartContext.Provider>
  );
}
