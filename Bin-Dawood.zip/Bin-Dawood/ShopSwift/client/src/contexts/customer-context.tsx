import { createContext, useContext, useState, ReactNode } from 'react';

type CustomerType = 'retail' | 'wholesale';

interface CustomerContextType {
  customerType: CustomerType;
  setCustomerType: (type: CustomerType) => void;
  toggleCustomerType: () => void;
}

const CustomerContext = createContext<CustomerContextType | undefined>(undefined);

export function useCustomer() {
  const context = useContext(CustomerContext);
  if (context === undefined) {
    throw new Error('useCustomer must be used within a CustomerProvider');
  }
  return context;
}

interface CustomerProviderProps {
  children: ReactNode;
}

export function CustomerProvider({ children }: CustomerProviderProps) {
  const [customerType, setCustomerType] = useState<CustomerType>('retail');

  const toggleCustomerType = () => {
    setCustomerType(prev => prev === 'retail' ? 'wholesale' : 'retail');
  };

  return (
    <CustomerContext.Provider value={{
      customerType,
      setCustomerType,
      toggleCustomerType,
    }}>
      {children}
    </CustomerContext.Provider>
  );
}
