import { useState } from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useCart } from '@/contexts/cart-context';
import { useCustomer } from '@/contexts/customer-context';
import { CustomerToggle } from '@/components/customer-toggle';
import { 
  Minus, 
  Plus, 
  Trash2, 
  ArrowLeft, 
  CreditCard, 
  Truck,
  ShieldCheck,
  Tag,
  Package
} from 'lucide-react';

export default function Cart() {
  const { items, updateItem, removeItem, clearCart, getTotalPrice, isLoading } = useCart();
  const { customerType } = useCustomer();
  const [promoCode, setPromoCode] = useState('');

  const subtotal = getTotalPrice();
  const shipping = subtotal > 500 ? 0 : 50;
  const tax = subtotal * 0.15; // 15% tax
  const total = subtotal + shipping + tax;

  const handleQuantityChange = (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) {
      removeItem(itemId);
    } else {
      updateItem(itemId, newQuantity);
    }
  };

  const handleApplyPromo = () => {
    // Placeholder for promo code functionality
    console.log('Applying promo code:', promoCode);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="text-cart-title">
                Shopping Cart
              </h1>
              <p className="text-muted-foreground" data-testid="text-cart-description">
                Review your items and proceed to checkout
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">Pricing:</span>
              <CustomerToggle size="sm" />
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <Link href="/products">
              <Button variant="ghost" size="sm" data-testid="button-continue-shopping">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Continue Shopping
              </Button>
            </Link>
            
            {items.length > 0 && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={clearCart}
                data-testid="button-clear-cart"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear Cart
              </Button>
            )}
          </div>
        </div>

        {items.length === 0 ? (
          /* Empty Cart */
          <div className="text-center py-16" data-testid="empty-cart">
            <div className="text-6xl mb-6">🛒</div>
            <h2 className="text-2xl font-semibold text-foreground mb-4">Your cart is empty</h2>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              Start adding products to your cart to see them here. 
              Browse our {customerType} collection to get started.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/products">
                <Button size="lg" data-testid="button-browse-products">
                  <Package className="mr-2 h-5 w-5" />
                  Browse Products
                </Button>
              </Link>
              {customerType === 'retail' && (
                <Link href="/wholesale">
                  <Button variant="outline" size="lg" data-testid="button-explore-wholesale">
                    Explore Wholesale
                  </Button>
                </Link>
              )}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              <Card data-testid="card-cart-items">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Cart Items ({items.length})</span>
                    <Badge variant="outline" data-testid="badge-customer-type">
                      {customerType} pricing
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {items.map((item) => {
                    const product = item.product;
                    if (!product) return null;

                    const price = customerType === 'wholesale' 
                      ? parseFloat(product.wholesalePrice) 
                      : parseFloat(product.retailPrice);

                    return (
                      <div key={item.id} className="flex items-center space-x-4 p-4 border border-border rounded-lg" data-testid={`cart-item-${item.id}`}>
                        <div className="flex-shrink-0">
                          <img
                            src={product.imageUrl || ''}
                            alt={product.name}
                            className="w-20 h-20 object-cover rounded-lg"
                            data-testid={`img-cart-item-${item.id}`}
                          />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-foreground truncate" data-testid={`text-item-name-${item.id}`}>
                            {product.name}
                          </h3>
                          <p className="text-sm text-muted-foreground truncate" data-testid={`text-item-description-${item.id}`}>
                            {product.shortDescription}
                          </p>
                          
                          {customerType === 'wholesale' && product.moq && item.quantity < product.moq && (
                            <Badge variant="destructive" className="mt-1 text-xs" data-testid={`badge-moq-warning-${item.id}`}>
                              MOQ: {product.moq} units
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                            data-testid={`button-decrease-${item.id}`}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          
                          <Input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value) || 1)}
                            className="w-20 text-center"
                            data-testid={`input-quantity-${item.id}`}
                          />
                          
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                            data-testid={`button-increase-${item.id}`}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                        
                        <div className="text-right">
                          <div className="font-semibold text-foreground" data-testid={`text-item-price-${item.id}`}>
                            ${(price * item.quantity).toFixed(2)}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            ${price.toFixed(2)} each
                          </div>
                        </div>
                        
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(item.id)}
                          className="text-destructive hover:text-destructive"
                          data-testid={`button-remove-${item.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>

              {/* Promo Code */}
              <Card data-testid="card-promo-code">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <Tag className="h-5 w-5 text-muted-foreground" />
                    <Input
                      placeholder="Enter promo code"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="flex-1"
                      data-testid="input-promo-code"
                    />
                    <Button 
                      onClick={handleApplyPromo}
                      disabled={!promoCode.trim()}
                      data-testid="button-apply-promo"
                    >
                      Apply
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div className="space-y-6">
              <Card data-testid="card-order-summary">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between" data-testid="row-subtotal">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span className="font-medium">${subtotal.toFixed(2)}</span>
                    </div>
                    
                    <div className="flex justify-between" data-testid="row-shipping">
                      <span className="text-muted-foreground">Shipping</span>
                      <span className="font-medium">
                        {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                      </span>
                    </div>
                    
                    <div className="flex justify-between" data-testid="row-tax">
                      <span className="text-muted-foreground">Tax (15%)</span>
                      <span className="font-medium">${tax.toFixed(2)}</span>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex justify-between text-lg font-semibold" data-testid="row-total">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>

                  {shipping > 0 && (
                    <div className="text-xs text-muted-foreground p-2 bg-muted rounded" data-testid="text-free-shipping-note">
                      💡 Add ${(500 - subtotal).toFixed(2)} more for free shipping
                    </div>
                  )}

                  <Button 
                    size="lg" 
                    className="w-full"
                    data-testid="button-checkout"
                  >
                    <CreditCard className="mr-2 h-5 w-5" />
                    Proceed to Checkout
                  </Button>

                  {customerType === 'wholesale' && (
                    <Link href="/wholesale">
                      <Button 
                        variant="outline" 
                        size="lg" 
                        className="w-full"
                        data-testid="button-request-quote"
                      >
                        Request Custom Quote
                      </Button>
                    </Link>
                  )}
                </CardContent>
              </Card>

              {/* Shipping Info */}
              <Card data-testid="card-shipping-info">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Truck className="h-5 w-5 text-primary" />
                      <div>
                        <div className="font-medium text-foreground">Free Shipping</div>
                        <div className="text-sm text-muted-foreground">On orders over $500</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <ShieldCheck className="h-5 w-5 text-primary" />
                      <div>
                        <div className="font-medium text-foreground">Secure Payment</div>
                        <div className="text-sm text-muted-foreground">256-bit SSL encryption</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Package className="h-5 w-5 text-primary" />
                      <div>
                        <div className="font-medium text-foreground">Quality Guarantee</div>
                        <div className="text-sm text-muted-foreground">30-day return policy</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Wholesale Note */}
              {customerType === 'wholesale' && (
                <Card className="border-primary/20 bg-primary/5" data-testid="card-wholesale-note">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-primary mb-2">Wholesale Customer</h3>
                    <p className="text-sm text-muted-foreground">
                      You're viewing wholesale prices. For custom quotes on large orders 
                      or special requirements, please contact our wholesale team.
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
