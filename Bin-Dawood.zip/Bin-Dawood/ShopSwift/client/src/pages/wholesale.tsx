import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { insertInquirySchema } from '@shared/schema';
import { Link } from 'wouter';
import { 
  Building2, 
  Users, 
  Globe, 
  TrendingUp, 
  CheckCircle, 
  File, 
  Download, 
  Calculator,
  Truck,
  Shield,
  Clock,
  DollarSign,
  Send,
  Package,
  Target,
  Award
} from 'lucide-react';

const wholesaleInquirySchema = insertInquirySchema.extend({
  inquiryType: z.literal('wholesale'),
  customerType: z.literal('wholesale'),
  estimatedVolume: z.string().optional(),
  businessType: z.string().optional(),
});

type WholesaleInquiryData = z.infer<typeof wholesaleInquirySchema>;

export default function Wholesale() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<WholesaleInquiryData>({
    resolver: zodResolver(wholesaleInquirySchema),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
      company: '',
      inquiryType: 'wholesale',
      message: '',
      customerType: 'wholesale',
      estimatedVolume: '',
      businessType: '',
    },
  });

  const submitInquiryMutation = useMutation({
    mutationFn: async (data: WholesaleInquiryData) => {
      const response = await apiRequest('POST', '/api/inquiries', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Wholesale Inquiry Submitted",
        description: "Thank you for your interest. Our wholesale team will contact you within 24 hours.",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Submit Inquiry",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: WholesaleInquiryData) => {
    setIsSubmitting(true);
    submitInquiryMutation.mutate(data);
    setIsSubmitting(false);
  };

  const benefits = [
    {
      icon: DollarSign,
      title: 'Competitive Wholesale Pricing',
      description: 'Volume-based discounts with transparent pricing structure',
      details: ['Tiered pricing based on order volume', 'Special rates for long-term contracts', 'Flexible payment terms']
    },
    {
      icon: Globe,
      title: 'Global Shipping Network',
      description: 'Reliable delivery to 50+ countries worldwide',
      details: ['Express shipping options', 'Consolidated shipments', 'Real-time tracking']
    },
    {
      icon: Shield,
      title: 'Quality Assurance',
      description: 'Premium products with international certifications',
      details: ['ISO certified products', 'Quality control inspections', 'Product warranties']
    },
    {
      icon: Users,
      title: 'Dedicated Account Management',
      description: 'Personal support for wholesale customers',
      details: ['Dedicated account manager', '24/7 customer support', 'Technical assistance']
    },
  ];

  const customerTypes = [
    {
      icon: Building2,
      title: 'Restaurants & Cafes',
      description: 'Commercial kitchen equipment and cookware',
      minOrder: 'From $2,000'
    },
    {
      icon: Package,
      title: 'Hotels & Resorts',
      description: 'Elegant tableware and buffet equipment',
      minOrder: 'From $5,000'
    },
    {
      icon: Target,
      title: 'Retailers & Distributors',
      description: 'Diverse product range for resale',
      minOrder: 'From $1,000'
    },
    {
      icon: Award,
      title: 'Catering Companies',
      description: 'Professional-grade serving equipment',
      minOrder: 'From $1,500'
    },
  ];

  const processSteps = [
    {
      step: '01',
      title: 'Submit Inquiry',
      description: 'Fill out our wholesale inquiry form with your business details'
    },
    {
      step: '02',
      title: 'Account Verification',
      description: 'Our team verifies your business credentials and requirements'
    },
    {
      step: '03',
      title: 'Custom Quote',
      description: 'Receive personalized pricing based on your order volume'
    },
    {
      step: '04',
      title: 'Partnership Begins',
      description: 'Start ordering with your dedicated account manager'
    },
  ];

  const stats = [
    { value: '25+', label: 'Years in Business' },
    { value: '50+', label: 'Countries Served' },
    { value: '5,000+', label: 'Products Available' },
    { value: '1,000+', label: 'Wholesale Partners' },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10" data-testid="section-wholesale-hero">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6" data-testid="text-wholesale-title">
                Wholesale <span className="text-primary">Solutions</span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed mb-8" data-testid="text-wholesale-description">
                Partner with Bin Dawood for competitive wholesale pricing, global shipping, 
                and dedicated support for your business. Join over 1,000 wholesale partners worldwide.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" onClick={() => document.getElementById('wholesale-form')?.scrollIntoView()} data-testid="button-get-quote">
                  <File className="mr-2 h-5 w-5" />
                  Request Quote
                </Button>
                <Button variant="outline" size="lg" data-testid="button-download-catalog">
                  <Download className="mr-2 h-5 w-5" />
                  Download Catalog
                </Button>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Modern wholesale warehouse with organized inventory" 
                className="rounded-xl shadow-xl w-full h-auto"
                data-testid="img-wholesale-warehouse"
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-xl"></div>
              <div className="absolute bottom-6 left-6 text-white" data-testid="text-warehouse-experience">
                <div className="text-2xl font-bold">1,000+ Partners</div>
                <div className="text-sm opacity-90">Worldwide Distribution</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white" data-testid="section-wholesale-stats">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center" data-testid={`wholesale-stat-${index}`}>
                <div className="text-3xl font-bold text-primary mb-2">{stat.value}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-secondary/30" data-testid="section-wholesale-benefits">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="text-benefits-title">
              Why Choose Our Wholesale Program?
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-benefits-description">
              Comprehensive benefits designed for business success
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon;
              return (
                <Card key={index} className="p-6" data-testid={`benefit-card-${index}`}>
                  <CardContent className="p-0">
                    <div className="flex items-start space-x-4">
                      <div className="bg-primary/10 p-3 rounded-full flex-shrink-0">
                        <IconComponent className="h-6 w-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-foreground mb-2">{benefit.title}</h3>
                        <p className="text-muted-foreground mb-4">{benefit.description}</p>
                        <ul className="space-y-1">
                          {benefit.details.map((detail, detailIndex) => (
                            <li key={detailIndex} className="flex items-center text-sm text-muted-foreground">
                              <CheckCircle className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
                              {detail}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Customer Types */}
      <section className="py-16" data-testid="section-customer-types">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="text-customer-types-title">
              Who We Serve
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-customer-types-description">
              Tailored solutions for different business types
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {customerTypes.map((type, index) => {
              const IconComponent = type.icon;
              return (
                <Card key={index} className="p-6 text-center hover:shadow-md transition-shadow" data-testid={`customer-type-${index}`}>
                  <CardContent className="p-0">
                    <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">{type.title}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{type.description}</p>
                    <Badge variant="outline" className="text-xs">
                      {type.minOrder}
                    </Badge>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process Steps */}
      <section className="py-16 bg-secondary/30" data-testid="section-wholesale-process">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="text-process-title">
              How It Works
            </h2>
            <p className="text-lg text-muted-foreground" data-testid="text-process-description">
              Simple steps to become a wholesale partner
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <div key={index} className="relative" data-testid={`process-step-${index}`}>
                <div className="text-center">
                  <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-lg font-bold">
                    {step.step}
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">{step.title}</h3>
                  <p className="text-sm text-muted-foreground">{step.description}</p>
                </div>
                {index < processSteps.length - 1 && (
                  <div className="hidden lg:block absolute top-6 left-full w-full">
                    <div className="border-t-2 border-dashed border-muted-foreground/30 -translate-x-6"></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Wholesale Inquiry Form */}
      <section id="wholesale-form" className="py-16" data-testid="section-wholesale-form">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center" data-testid="text-form-title">
                Request Wholesale Quote
              </CardTitle>
              <p className="text-center text-muted-foreground" data-testid="text-form-description">
                Fill out the form below and our wholesale team will contact you within 24 hours
              </p>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="form-wholesale-inquiry">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Contact Person *</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Your full name" 
                              {...field} 
                              data-testid="input-wholesale-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Email *</FormLabel>
                          <FormControl>
                            <Input 
                              type="email" 
                              placeholder="business@company.com" 
                              {...field} 
                              data-testid="input-wholesale-email"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number *</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="+966 XXX XXX XXX" 
                              {...field}
                              value={field.value || ''}
                              data-testid="input-wholesale-phone"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Name *</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Your company name" 
                              {...field}
                              value={field.value || ''}
                              data-testid="input-wholesale-company"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="businessType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-business-type">
                                <SelectValue placeholder="Select business type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="restaurant">Restaurant/Cafe</SelectItem>
                              <SelectItem value="hotel">Hotel/Resort</SelectItem>
                              <SelectItem value="retailer">Retailer/Distributor</SelectItem>
                              <SelectItem value="catering">Catering Company</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="estimatedVolume"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Estimated Monthly Volume</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-volume">
                                <SelectValue placeholder="Select volume range" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="1000-5000">$1,000 - $5,000</SelectItem>
                              <SelectItem value="5000-10000">$5,000 - $10,000</SelectItem>
                              <SelectItem value="10000-25000">$10,000 - $25,000</SelectItem>
                              <SelectItem value="25000+">$25,000+</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Additional Information *</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Tell us about your business needs, specific products of interest, and any other requirements..."
                            className="min-h-32"
                            {...field}
                            data-testid="textarea-wholesale-message"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button 
                    type="submit" 
                    size="lg" 
                    className="w-full"
                    disabled={isSubmitting || submitInquiryMutation.isPending}
                    data-testid="button-submit-wholesale-form"
                  >
                    <Send className="mr-2 h-5 w-5" />
                    {isSubmitting || submitInquiryMutation.isPending ? 'Submitting...' : 'Submit Wholesale Inquiry'}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10" data-testid="section-wholesale-cta">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4" data-testid="text-cta-title">
            Ready to Start Your Wholesale Partnership?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-cta-description">
            Join over 1,000 businesses worldwide who trust Bin Dawood for their kitchenware needs. 
            Get competitive pricing and dedicated support today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" data-testid="button-cta-contact">
                Contact Sales Team
              </Button>
            </Link>
            <Link href="/products">
              <Button variant="outline" size="lg" data-testid="button-cta-browse">
                Browse Products
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
