import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { 
  MapPin, 
  Users, 
  Globe, 
  Award, 
  Truck, 
  Shield, 
  Clock, 
  Star,
  Building2,
  Factory
} from 'lucide-react';

export default function About() {
  const stats = [
    { icon: Clock, value: '25+', label: 'Years Experience' },
    { icon: Globe, value: '50+', label: 'Countries Served' },
    { icon: Users, value: '10,000+', label: 'Satisfied Customers' },
    { icon: Award, value: '5,000+', label: 'Products Available' },
  ];

  const services = [
    {
      icon: Building2,
      title: 'Wholesale Distribution',
      description: 'Bulk orders with competitive pricing for restaurants, hotels, and retailers worldwide.'
    },
    {
      icon: Factory,
      title: 'Retail Sales',
      description: 'Individual purchases for households and small businesses with flexible ordering.'
    },
    {
      icon: Truck,
      title: 'Global Shipping',
      description: 'Reliable delivery services to over 50 countries with tracking and insurance.'
    },
    {
      icon: Shield,
      title: 'Quality Assurance',
      description: 'Rigorous quality control and international certifications for all products.'
    },
  ];

  const timeline = [
    {
      year: '1999',
      title: 'Company Founded',
      description: 'Bin Dawood established in International Market with focus on kitchenware.'
    },
    {
      year: '2005',
      title: 'International Expansion',
      description: 'Began exporting to neighboring countries and established wholesale partnerships.'
    },
    {
      year: '2010',
      title: 'Product Line Growth',
      description: 'Expanded product range to include restaurant and hotel ware collections.'
    },
    {
      year: '2015',
      title: 'Digital Transformation',
      description: 'Launched online platform for both wholesale and retail customers.'
    },
    {
      year: '2020',
      title: 'Global Reach',
      description: 'Achieved presence in 50+ countries with dedicated logistics network.'
    },
    {
      year: '2024',
      title: 'Innovation Focus',
      description: 'Continued growth with focus on sustainable and innovative kitchenware solutions.'
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10" data-testid="section-about-hero">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6" data-testid="text-about-title">
                About <span className="text-primary">Bin Dawood</span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed mb-8" data-testid="text-about-description">
                For over 25 years, Bin Dawood has been a trusted name in the kitchenware industry, 
                serving restaurants, hotels, and households across the globe with premium quality 
                products and exceptional service.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/wholesale">
                  <Button size="lg" data-testid="button-wholesale-info">
                    Wholesale Information
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button variant="outline" size="lg" data-testid="button-contact-us">
                    Contact Us
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Bin Dawood headquarters and warehouse facility" 
                className="rounded-xl shadow-xl w-full h-auto"
                data-testid="img-about-facility"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16" data-testid="section-stats">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <div key={index} className="text-center" data-testid={`stat-card-${index}`}>
                  <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="h-8 w-8 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-2">{stat.value}</div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-secondary/30" data-testid="section-mission-vision">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card className="p-8" data-testid="card-mission">
              <h3 className="text-2xl font-bold text-foreground mb-4">Our Mission</h3>
              <p className="text-muted-foreground leading-relaxed">
                To provide high-quality kitchenware and restaurant supplies that enable our customers 
                to excel in their culinary endeavors, whether they're running a professional kitchen 
                or cooking at home. We are committed to offering competitive wholesale and retail 
                pricing while maintaining the highest standards of quality and service.
              </p>
            </Card>
            
            <Card className="p-8" data-testid="card-vision">
              <h3 className="text-2xl font-bold text-foreground mb-4">Our Vision</h3>
              <p className="text-muted-foreground leading-relaxed">
                To be the leading global supplier of kitchenware and restaurant equipment, 
                recognized for our innovation, reliability, and customer-centric approach. 
                We envision a world where quality kitchen tools are accessible to everyone, 
                from international hotel chains to home cooking enthusiasts.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-16" data-testid="section-services">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4" data-testid="text-services-title">
              Our Services
            </h3>
            <p className="text-lg text-muted-foreground" data-testid="text-services-description">
              Comprehensive solutions for all your kitchenware needs
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <Card key={index} className="p-6 text-center hover:shadow-md transition-shadow" data-testid={`service-card-${index}`}>
                  <CardContent className="p-0">
                    <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="h-6 w-6 text-primary" />
                    </div>
                    <h4 className="text-lg font-semibold text-foreground mb-3">{service.title}</h4>
                    <p className="text-sm text-muted-foreground">{service.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 bg-secondary/30" data-testid="section-timeline">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4" data-testid="text-timeline-title">
              Our Journey
            </h3>
            <p className="text-lg text-muted-foreground" data-testid="text-timeline-description">
              25+ years of growth and innovation in the kitchenware industry
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {timeline.map((milestone, index) => (
              <Card key={index} className="p-6 relative" data-testid={`timeline-card-${index}`}>
                <Badge className="absolute -top-3 left-6" data-testid={`badge-year-${index}`}>
                  {milestone.year}
                </Badge>
                <CardContent className="p-0 pt-4">
                  <h4 className="text-lg font-semibold text-foreground mb-3">{milestone.title}</h4>
                  <p className="text-sm text-muted-foreground">{milestone.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quality & Certifications */}
      <section className="py-16" data-testid="section-quality">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold text-foreground mb-6" data-testid="text-quality-title">
                Quality & Certifications
              </h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-2 rounded-full flex-shrink-0">
                    <Award className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">International Standards</h4>
                    <p className="text-muted-foreground">All products meet international quality standards and safety regulations.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-2 rounded-full flex-shrink-0">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Quality Control</h4>
                    <p className="text-muted-foreground">Rigorous testing and inspection processes ensure consistent quality.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-2 rounded-full flex-shrink-0">
                    <Star className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Customer Satisfaction</h4>
                    <p className="text-muted-foreground">Dedicated to maintaining high customer satisfaction ratings globally.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Quality control and testing facility" 
                className="rounded-xl shadow-xl w-full h-auto"
                data-testid="img-quality"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10" data-testid="section-contact-cta">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl font-bold text-foreground mb-4" data-testid="text-cta-title">
            Ready to Work With Us?
          </h3>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto" data-testid="text-cta-description">
            Whether you're looking for wholesale opportunities or retail purchases, 
            we're here to help you find the perfect kitchenware solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/wholesale">
              <Button size="lg" data-testid="button-cta-wholesale">
                Explore Wholesale
              </Button>
            </Link>
            <Link href="/contact">
              <Button variant="outline" size="lg" data-testid="button-cta-contact">
                Get in Touch
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
