import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ProductCard } from '@/components/product-card';
import { CategoryCard } from '@/components/category-card';
import { CustomerToggle } from '@/components/customer-toggle';
import { useCustomer } from '@/contexts/customer-context';
import { 
  Store, 
  Handshake, 
  Medal, 
  Truck, 
  Headset, 
  DollarSign, 
  CheckCircle, 
  File, 
  Download,
  Inbox,
  Send,
  ArrowRight,
  ChevronUp,
  MessageCircle
} from 'lucide-react';
import type { Product, Category } from '@shared/schema';

export default function Home() {
  const { customerType } = useCustomer();

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const { data: featuredProducts = [] } = useQuery<Product[]>({
    queryKey: ['/api/products', { featured: true }],
  });

  const stats = [
    { value: '5000+', label: 'Products' },
    { value: '50+', label: 'Countries Served' },
    { value: '25+', label: 'Years Experience' },
  ];

  const benefits = [
    { icon: Medal, title: 'Premium Quality', description: 'International standards with rigorous quality control' },
    { icon: Truck, title: 'Fast Delivery', description: 'Quick processing and reliable worldwide shipping' },
    { icon: Headset, title: '24/7 Support', description: 'Dedicated customer service and technical support' },
    { icon: DollarSign, title: 'Best Prices', description: 'Competitive wholesale and retail pricing' },
  ];

  const wholesaleBenefits = [
    { title: 'Bulk Pricing', description: 'Competitive wholesale rates with volume discounts' },
    { title: 'Global Shipping', description: 'Reliable delivery to 50+ countries worldwide' },
    { title: 'Quality Assurance', description: 'Premium products with international certifications' },
    { title: 'Dedicated Support', description: 'Personal account manager for wholesale customers' },
  ];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary/5 via-white to-primary/5" data-testid="section-hero">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div>
                <h2 className="hero-text font-bold text-foreground leading-tight" data-testid="text-hero-title">
                  Professional <span className="text-primary">Kitchenware</span> for Every Need
                </h2>
                <p className="mt-6 text-xl text-muted-foreground leading-relaxed" data-testid="text-hero-description">
                  Serving restaurants, hotels, and households with premium quality cookware, cutlery, and kitchen essentials. 
                  <strong> Wholesale and retail options available.</strong>
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/products">
                  <Button size="lg" data-testid="button-shop-retail">
                    <Store className="mr-2 h-5 w-5" />
                    Shop Retail
                  </Button>
                </Link>
                <Link href="/wholesale">
                  <Button variant="outline" size="lg" data-testid="button-wholesale-quote">
                    <Handshake className="mr-2 h-5 w-5" />
                    Request Wholesale Quote
                  </Button>
                </Link>
              </div>
              
              <div className="flex items-center space-x-8 pt-4">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center" data-testid={`stat-${index}`}>
                    <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Professional kitchen setup with cookware" 
                className="rounded-xl shadow-2xl w-full h-auto"
                data-testid="img-hero"
              />
              
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg" data-testid="badge-quality">
                <div className="text-sm font-semibold text-primary">✓ International Quality</div>
              </div>
              <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg" data-testid="badge-bulk">
                <div className="text-sm font-semibold text-primary">✓ Bulk Orders Available</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Categories */}
      <section className="py-16 bg-secondary/30" data-testid="section-categories">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4" data-testid="text-categories-title">
              Shop by Category
            </h3>
            <p className="text-lg text-muted-foreground" data-testid="text-categories-description">
              Discover our comprehensive range of professional kitchenware and supplies
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16" data-testid="section-featured-products">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h3 className="text-3xl font-bold text-foreground mb-4" data-testid="text-featured-title">
                Featured Products
              </h3>
              <p className="text-lg text-muted-foreground" data-testid="text-featured-description">
                Premium quality products for professional kitchens
              </p>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">Showing prices for:</span>
              <CustomerToggle size="sm" />
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link href="/products">
              <Button variant="outline" size="lg" data-testid="button-view-all-products">
                View All Products
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Wholesale CTA */}
      <section className="py-16 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10" data-testid="section-wholesale-cta">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold text-foreground mb-6" data-testid="text-wholesale-title">
                Wholesale Solutions for Your Business
              </h3>
              <div className="space-y-4 mb-8">
                {wholesaleBenefits.map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-3" data-testid={`benefit-${index}`}>
                    <CheckCircle className="text-primary mt-1 h-5 w-5 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-foreground">{benefit.title}</h4>
                      <p className="text-muted-foreground">{benefit.description}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/wholesale">
                  <Button size="lg" data-testid="button-request-quote">
                    <File className="mr-2 h-5 w-5" />
                    Request Quote
                  </Button>
                </Link>
                <Button variant="outline" size="lg" data-testid="button-download-catalog">
                  <Download className="mr-2 h-5 w-5" />
                  Download Catalog
                </Button>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Modern wholesale warehouse with organized inventory" 
                className="rounded-xl shadow-xl w-full h-auto"
                data-testid="img-wholesale"
              />
              
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-xl"></div>
              <div className="absolute bottom-6 left-6 text-white" data-testid="text-warehouse-years">
                <div className="text-2xl font-bold">25+ Years</div>
                <div className="text-sm opacity-90">Serving Global Markets</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16" data-testid="section-why-choose-us">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-4" data-testid="text-why-choose-title">
              Why Choose Bin Dawood?
            </h3>
            <p className="text-lg text-muted-foreground" data-testid="text-why-choose-description">
              Trusted by restaurants, hotels, and households worldwide
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon;
              return (
                <div key={index} className="text-center" data-testid={`benefit-card-${index}`}>
                  <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="h-8 w-8 text-primary" />
                  </div>
                  <h4 className="text-lg font-semibold text-foreground mb-2">{benefit.title}</h4>
                  <p className="text-muted-foreground">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Newsletter & Quick Contact */}
      <section className="py-16 bg-secondary/30" data-testid="section-contact-forms">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Newsletter Signup */}
            <Card className="p-8" data-testid="card-newsletter">
              <h4 className="text-2xl font-bold text-foreground mb-4" data-testid="text-newsletter-title">
                Stay Updated
              </h4>
              <p className="text-muted-foreground mb-6" data-testid="text-newsletter-description">
                Get the latest product updates, industry news, and special offers.
              </p>
              
              <form className="space-y-4" data-testid="form-newsletter">
                <Input
                  type="email"
                  placeholder="Enter your email address"
                  data-testid="input-newsletter-email"
                />
                <div className="flex items-center space-x-3">
                  <Checkbox id="wholesale-updates" data-testid="checkbox-wholesale-updates" />
                  <label htmlFor="wholesale-updates" className="text-sm text-muted-foreground">
                    I'm interested in wholesale pricing and bulk orders
                  </label>
                </div>
                <Button type="submit" className="w-full" size="lg" data-testid="button-subscribe">
                  <Inbox className="mr-2 h-5 w-5" />
                  Subscribe Now
                </Button>
              </form>
            </Card>
            
            {/* Quick Contact */}
            <Card className="p-8" data-testid="card-quick-contact">
              <h4 className="text-2xl font-bold text-foreground mb-4" data-testid="text-contact-title">
                Quick Inquiry
              </h4>
              <p className="text-muted-foreground mb-6" data-testid="text-contact-description">
                Have questions? Send us a message and we'll get back to you quickly.
              </p>
              
              <form className="space-y-4" data-testid="form-quick-contact">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input
                    type="text"
                    placeholder="Your Name"
                    data-testid="input-contact-name"
                  />
                  <Input
                    type="email"
                    placeholder="Your Email"
                    data-testid="input-contact-email"
                  />
                </div>
                <Select>
                  <SelectTrigger data-testid="select-inquiry-type">
                    <SelectValue placeholder="Select inquiry type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General Inquiry</SelectItem>
                    <SelectItem value="wholesale">Wholesale Quote Request</SelectItem>
                    <SelectItem value="product">Product Information</SelectItem>
                    <SelectItem value="support">Technical Support</SelectItem>
                  </SelectContent>
                </Select>
                <Textarea
                  placeholder="Your message..."
                  rows={4}
                  data-testid="textarea-contact-message"
                />
                <Button type="submit" className="w-full" size="lg" data-testid="button-send-message">
                  <Send className="mr-2 h-5 w-5" />
                  Send Message
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </section>

      {/* Fixed Elements */}
      <div className="fixed bottom-6 right-6 flex flex-col space-y-3 z-40" data-testid="fixed-elements">
        {/* WhatsApp Button */}
        <Button 
          size="icon" 
          className="bg-green-500 hover:bg-green-600 text-white w-14 h-14 rounded-full shadow-lg"
          data-testid="button-whatsapp"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
        
        {/* Scroll to Top */}
        <Button 
          size="icon" 
          onClick={scrollToTop}
          className="w-14 h-14 rounded-full shadow-lg"
          data-testid="button-scroll-top"
        >
          <ChevronUp className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
