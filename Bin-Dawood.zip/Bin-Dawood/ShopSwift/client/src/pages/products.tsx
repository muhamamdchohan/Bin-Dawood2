import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ProductCard } from '@/components/product-card';
import { CustomerToggle } from '@/components/customer-toggle';
import { Search, Filter, Grid, List } from 'lucide-react';
import type { Product, Category } from '@shared/schema';

export default function Products() {
  const [location] = useLocation();
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  
  const [searchQuery, setSearchQuery] = useState(urlParams.get('search') || '');
  const [categoryFilter, setCategoryFilter] = useState(urlParams.get('category') || 'all');
  const [sortBy, setSortBy] = useState('name');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', { search: searchQuery, categoryId: categoryFilter === 'all' ? undefined : categoryFilter }],
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Update URL params would go here
  };

  const filteredAndSortedProducts = products
    .filter(product => {
      if (!searchQuery) return true;
      return product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
             product.description?.toLowerCase().includes(searchQuery.toLowerCase());
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return parseFloat(a.retailPrice) - parseFloat(b.retailPrice);
        case 'price-high':
          return parseFloat(b.retailPrice) - parseFloat(a.retailPrice);
        case 'name':
        default:
          return a.name.localeCompare(b.name);
      }
    });

  const selectedCategory = categoryFilter === 'all' ? null : categories.find(cat => cat.slug === categoryFilter);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="text-products-title">
                {selectedCategory ? selectedCategory.name : 'All Products'}
              </h1>
              <p className="text-muted-foreground" data-testid="text-products-description">
                {selectedCategory 
                  ? selectedCategory.description 
                  : 'Discover our complete range of professional kitchenware'}
              </p>
            </div>
            
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <span className="text-sm text-muted-foreground">Showing prices for:</span>
              <CustomerToggle size="sm" />
            </div>
          </div>

          {/* Search and Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-products"
              />
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            </form>

            <Select value={categoryFilter} onValueChange={setCategoryFilter} data-testid="select-category-filter">
              <SelectTrigger>
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.slug}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy} data-testid="select-sort">
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Sort by Name</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center space-x-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('grid')}
                data-testid="button-view-grid"
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('list')}
                data-testid="button-view-list"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Active Filters */}
          <div className="flex flex-wrap gap-2">
            {searchQuery && (
              <Badge variant="secondary" className="flex items-center gap-1" data-testid="badge-search-filter">
                Search: {searchQuery}
                <button onClick={() => setSearchQuery('')} className="ml-1 hover:text-foreground">×</button>
              </Badge>
            )}
            {categoryFilter && categoryFilter !== 'all' && (
              <Badge variant="secondary" className="flex items-center gap-1" data-testid="badge-category-filter">
                Category: {selectedCategory?.name}
                <button onClick={() => setCategoryFilter('all')} className="ml-1 hover:text-foreground">×</button>
              </Badge>
            )}
          </div>
        </div>

        {/* Products Grid/List */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="animate-pulse-gentle border border-border/30" data-testid={`skeleton-product-${i}`}>
                <div className="aspect-square bg-gradient-to-br from-muted to-muted/50 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-pulse"></div>
                </div>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <div className="h-3 bg-gradient-to-r from-muted to-muted/50 rounded-full w-16"></div>
                      <div className="h-3 bg-gradient-to-r from-muted to-muted/50 rounded-full w-20"></div>
                    </div>
                    <div className="h-5 bg-gradient-to-r from-muted to-muted/50 rounded w-full"></div>
                    <div className="h-4 bg-gradient-to-r from-muted to-muted/50 rounded w-3/4"></div>
                    <div className="space-y-2">
                      <div className="h-6 bg-gradient-to-r from-muted to-muted/50 rounded w-1/2"></div>
                      <div className="h-3 bg-gradient-to-r from-muted to-muted/50 rounded w-full"></div>
                    </div>
                    <div className="flex gap-2">
                      <div className="h-10 bg-gradient-to-r from-muted to-muted/50 rounded flex-1"></div>
                      <div className="h-10 bg-gradient-to-r from-muted to-muted/50 rounded w-10"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <>
            {filteredAndSortedProducts.length > 0 ? (
              <div className={viewMode === 'grid' 
                ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6' 
                : 'space-y-4'
              }>
                {filteredAndSortedProducts.map((product) => (
                  <ProductCard 
                    key={product.id} 
                    product={product} 
                    className={viewMode === 'list' ? 'flex flex-row' : ''}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16" data-testid="empty-state">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-2xl font-semibold text-foreground mb-2">No products found</h3>
                <p className="text-muted-foreground mb-6">
                  Try adjusting your search criteria or browse our categories.
                </p>
                <Button onClick={() => {
                  setSearchQuery('');
                  setCategoryFilter('all');
                }} data-testid="button-clear-filters">
                  Clear Filters
                </Button>
              </div>
            )}
          </>
        )}

        {/* Results Info */}
        {filteredAndSortedProducts.length > 0 && (
          <div className="mt-8 text-center" data-testid="text-results-info">
            <p className="text-muted-foreground">
              Showing {filteredAndSortedProducts.length} of {products.length} products
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
