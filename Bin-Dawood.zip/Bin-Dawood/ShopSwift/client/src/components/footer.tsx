import { Link } from 'wouter';
import { Facebook, Instagram, Linkedin, MessageCircle, MapPin, Phone, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Footer() {
  const productCategories = [
    { name: 'Kitchenware', href: '/products?category=kitchenware' },
    { name: 'Non-stick Cookware', href: '/products?category=non-stick-cookware' },
    { name: 'Dinner Sets & Crockery', href: '/products?category=dinner-sets' },
    { name: 'Cutlery', href: '/products?category=cutlery' },
    { name: 'Household Items', href: '/products?category=household-items' },
    { name: 'Restaurant Ware', href: '/products?category=restaurant-ware' },
    { name: 'Hotel Ware', href: '/products?category=hotel-ware' },
  ];

  const customerService = [
    { name: 'Wholesale Portal', href: '/wholesale' },
    { name: 'Order Tracking', href: '/contact' },
    { name: 'Shipping Information', href: '/about' },
    { name: 'Return Policy', href: '/about' },
    { name: 'FAQ', href: '/about' },
    { name: 'Contact Support', href: '/contact' },
    { name: 'Bulk Orders', href: '/wholesale' },
  ];

  const legal = [
    { name: 'Privacy Policy', href: '/privacy' },
    { name: 'Terms of Service', href: '/terms' },
    { name: 'Wholesale Terms', href: '/wholesale' },
  ];

  const socialLinks = [
    { name: 'Facebook', icon: Facebook, href: '#', color: 'hover:text-blue-600' },
    { name: 'Instagram', icon: Instagram, href: '#', color: 'hover:text-pink-600' },
    { name: 'LinkedIn', icon: Linkedin, href: '#', color: 'hover:text-blue-700' },
    { name: 'WhatsApp', icon: MessageCircle, href: '#', color: 'hover:text-green-600' },
  ];

  return (
    <footer className="bg-foreground text-background py-16" data-testid="footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-2xl font-bold text-primary mb-4" data-testid="text-company-name">
              BIN DAWOOD
            </h3>
            <p className="text-background/80 mb-6" data-testid="text-company-description">
              Leading supplier of professional kitchenware and restaurant supplies, 
              serving wholesale and retail customers worldwide for over 25 years.
            </p>
            <div className="space-y-3">
              <div className="flex items-center space-x-3" data-testid="text-address">
                <MapPin className="h-4 w-4 text-primary flex-shrink-0" />
                <span className="text-background/80">International Market</span>
              </div>
              <div className="flex items-center space-x-3" data-testid="text-phone">
                <Phone className="h-4 w-4 text-primary flex-shrink-0" />
                <span className="text-background/80">+966 XXX XXX XXX</span>
              </div>
              <div className="flex items-center space-x-3" data-testid="text-email">
                <Mail className="h-4 w-4 text-primary flex-shrink-0" />
                <span className="text-background/80">info@bindawood.com</span>
              </div>
            </div>
          </div>
          
          {/* Product Categories */}
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="text-categories-title">
              Product Categories
            </h4>
            <ul className="space-y-2 text-background/80">
              {productCategories.map((category) => (
                <li key={category.name}>
                  <Link href={category.href}>
                    <Button
                      variant="link"
                      className="p-0 h-auto text-background/80 hover:text-primary font-normal text-left"
                      data-testid={`link-category-${category.name.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {category.name}
                    </Button>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Customer Service */}
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="text-service-title">
              Customer Service
            </h4>
            <ul className="space-y-2 text-background/80">
              {customerService.map((service) => (
                <li key={service.name}>
                  <Link href={service.href}>
                    <Button
                      variant="link"
                      className="p-0 h-auto text-background/80 hover:text-primary font-normal text-left"
                      data-testid={`link-service-${service.name.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {service.name}
                    </Button>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Connect & Legal */}
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="text-connect-title">
              Connect With Us
            </h4>
            <div className="flex space-x-4 mb-6">
              {socialLinks.map((social) => {
                const IconComponent = social.icon;
                return (
                  <Button
                    key={social.name}
                    variant="ghost"
                    size="icon"
                    className={`text-background/80 ${social.color} transition-colors`}
                    data-testid={`link-social-${social.name.toLowerCase()}`}
                  >
                    <IconComponent className="h-5 w-5" />
                  </Button>
                );
              })}
            </div>
            
            <h5 className="font-semibold mb-2" data-testid="text-legal-title">Legal</h5>
            <ul className="space-y-2 text-background/80">
              {legal.map((item) => (
                <li key={item.name}>
                  <Link href={item.href}>
                    <Button
                      variant="link"
                      className="p-0 h-auto text-background/80 hover:text-primary font-normal text-left"
                      data-testid={`link-legal-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {item.name}
                    </Button>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-background/20 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-background/60 text-sm" data-testid="text-copyright">
              © 2024 Bin Dawood. All rights reserved. Professional kitchenware supplier.
            </p>
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <span className="text-background/60 text-sm">Payment Methods:</span>
              <div className="flex space-x-2" data-testid="text-payment-methods">
                <span className="text-xl text-background/60">💳</span>
                <span className="text-xl text-background/60">💰</span>
                <span className="text-xl text-background/60">🏦</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
