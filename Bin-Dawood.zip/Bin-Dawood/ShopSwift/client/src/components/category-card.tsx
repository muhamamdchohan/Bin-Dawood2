import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Category } from '@shared/schema';
import { Link } from 'wouter';

interface CategoryCardProps {
  category: Category;
  className?: string;
}

export function CategoryCard({ category, className = '' }: CategoryCardProps) {
  return (
    <Link href={`/products?category=${category.slug}`}>
      <Card className={`category-card cursor-pointer border border-border/50 hover:border-primary/30 group transition-all duration-300 ${className}`} data-testid={`card-category-${category.slug}`}>
        <div className="aspect-square overflow-hidden relative">
          <img
            src={category.imageUrl || ''}
            alt={category.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            data-testid={`img-category-${category.slug}`}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
          <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
            <h4 className="text-xl font-bold mb-2 drop-shadow-lg" data-testid={`text-name-${category.slug}`}>
              {category.name}
            </h4>
            <Badge className="bg-white/20 backdrop-blur-sm text-white border-white/30 hover:bg-white/30" data-testid={`text-count-${category.slug}`}>
              {category.productCount}+ Products
            </Badge>
          </div>
        </div>
        <CardContent className="p-6 text-center">
          <p className="text-sm text-muted-foreground leading-relaxed group-hover:text-foreground transition-colors duration-200" data-testid={`text-description-${category.slug}`}>
            {category.description}
          </p>
          <div className="mt-4 flex items-center justify-center text-primary group-hover:text-primary/80 transition-colors duration-200">
            <span className="text-sm font-medium">Explore Collection</span>
            <svg className="ml-2 h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
