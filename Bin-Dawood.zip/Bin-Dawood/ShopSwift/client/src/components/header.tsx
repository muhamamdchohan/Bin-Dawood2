import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Search, Heart, ShoppingCart, Menu, X, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { CustomerToggle } from './customer-toggle';
import { useCart } from '@/contexts/cart-context';
import { useIsMobile } from '@/hooks/use-mobile';

export function Header() {
  const [location, navigate] = useLocation();
  const { totalItems } = useCart();
  const [searchQuery, setSearchQuery] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'Products', href: '/products' },
    { name: 'Categories', href: '/products' },
    { name: 'Wholesale', href: '/wholesale' },
    { name: 'About', href: '/about' },
    { name: 'Contact', href: '/contact' },
  ];

  const MobileMenu = () => (
    <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" data-testid="button-mobile-menu">
          <Menu className="h-6 w-6" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-80" data-testid="sheet-mobile-menu">
        <div className="flex flex-col space-y-6 mt-8">
          <CustomerToggle />
          
          <form onSubmit={handleSearch} className="space-y-2">
            <Input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-mobile-search"
            />
            <Button type="submit" className="w-full" data-testid="button-mobile-search">
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </form>
          
          <nav className="space-y-2">
            {navigation.map((item) => (
              <Link key={item.name} href={item.href}>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => setIsMenuOpen(false)}
                  data-testid={`link-mobile-${item.name.toLowerCase()}`}
                >
                  {item.name}
                </Button>
              </Link>
            ))}
          </nav>
        </div>
      </SheetContent>
    </Sheet>
  );

  return (
    <header className="bg-white/95 backdrop-blur-md shadow-lg border-b border-border/50 sticky top-0 z-50 transition-all duration-300" data-testid="header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center cursor-pointer group" data-testid="link-logo">
              <div className="flex-shrink-0">
                <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent group-hover:from-primary/80 group-hover:to-primary transition-all duration-300">
                  BIN DAWOOD
                </h1>
                <p className="text-xs text-muted-foreground/80 font-medium tracking-wide">Professional Kitchenware</p>
              </div>
            </div>
          </Link>
          
          {/* Customer Type Toggle - Desktop */}
          {!isMobile && (
            <div className="hidden md:flex items-center space-x-4">
              <CustomerToggle />
            </div>
          )}
          
          {/* Search Bar - Desktop */}
          {!isMobile && (
            <div className="hidden md:flex flex-1 max-w-lg mx-8">
              <form onSubmit={handleSearch} className="relative w-full group">
                <Input
                  type="text"
                  placeholder="Search professional kitchenware..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 h-11 rounded-full border-2 transition-all duration-300 focus:border-primary/50 focus:ring-4 focus:ring-primary/10 hover:border-primary/30"
                  data-testid="input-search"
                />
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors duration-200" />
              </form>
            </div>
          )}
          
          {/* Navigation Icons */}
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="hover:bg-primary/10 hover:text-primary transition-all duration-200 rounded-full" data-testid="button-wishlist" aria-label="Add to wishlist">
              <Heart className="h-5 w-5" />
            </Button>
            
            <Link href="/cart">
              <Button variant="ghost" size="icon" className="relative hover:bg-primary/10 hover:text-primary transition-all duration-200 rounded-full" data-testid="button-cart" aria-label="View shopping cart">
                <ShoppingCart className="h-5 w-5" />
                {totalItems > 0 && (
                  <Badge 
                    className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs bg-primary text-white border-2 border-white animate-pulse-gentle"
                    data-testid="badge-cart-count"
                  >
                    {totalItems}
                  </Badge>
                )}
              </Button>
            </Link>
            
            {isMobile && <MobileMenu />}
          </div>
        </div>
      </div>
      
      {/* Navigation Menu - Desktop */}
      {!isMobile && (
        <nav className="bg-gradient-to-r from-white/95 to-white/98 backdrop-blur-sm border-t border-border/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-14">
              <div className="hidden md:flex space-x-2">
                {navigation.map((item) => (
                  <Link key={item.name} href={item.href}>
                    <Button
                      variant="ghost"
                      className={`font-medium px-4 py-2 rounded-full transition-all duration-300 ${
                        location === item.href 
                          ? 'text-primary bg-primary/10 shadow-sm' 
                          : 'text-muted-foreground hover:text-primary hover:bg-primary/5'
                      }`}
                      data-testid={`link-${item.name.toLowerCase()}`}
                    >
                      {item.name}
                    </Button>
                  </Link>
                ))}
              </div>
              
              <div className="hidden md:flex items-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4 text-primary" />
                  <span>+966 XXX XXX XXX</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-green-600">📱</span>
                  <span>WhatsApp Support</span>
                </div>
              </div>
            </div>
          </div>
        </nav>
      )}
    </header>
  );
}
