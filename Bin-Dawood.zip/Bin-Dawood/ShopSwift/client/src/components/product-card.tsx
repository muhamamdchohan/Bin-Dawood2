import { useState } from 'react';
import { useCustomer } from '@/contexts/customer-context';
import { useCart } from '@/contexts/cart-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Heart } from 'lucide-react';
import type { Product } from '@shared/schema';

interface ProductCardProps {
  product: Product;
  className?: string;
}

export function ProductCard({ product, className = '' }: ProductCardProps) {
  const { customerType } = useCustomer();
  const { addItem } = useCart();
  const [isLoading, setIsLoading] = useState(false);

  const price = customerType === 'wholesale' 
    ? parseFloat(product.wholesalePrice) 
    : parseFloat(product.retailPrice);

  const otherPrice = customerType === 'retail' 
    ? parseFloat(product.wholesalePrice) 
    : parseFloat(product.retailPrice);

  const handleAddToCart = async () => {
    setIsLoading(true);
    addItem(product.id);
    setIsLoading(false);
  };

  return (
    <Card className={`product-card overflow-hidden border border-border/50 hover:border-primary/30 group ${className}`} data-testid={`card-product-${product.id}`}>
      <div className="aspect-square overflow-hidden relative">
        <img
          src={product.imageUrl || ''}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          data-testid={`img-product-${product.id}`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
          <Button 
            variant="secondary" 
            size="icon"
            className="h-8 w-8 bg-white/90 backdrop-blur-sm hover:bg-white border-0 shadow-lg"
            data-testid={`button-quick-view-${product.id}`}
            aria-label="Add to wishlist"
          >
            <Heart className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            {product.featured && (
              <Badge className="text-xs bg-gradient-to-r from-primary to-primary/90 text-white border-0" data-testid="badge-featured">
                ⭐ Featured
              </Badge>
            )}
            {product.inStock ? (
              <Badge variant="outline" className="text-xs text-green-600 border-green-200 bg-green-50">
                In Stock
              </Badge>
            ) : (
              <Badge variant="outline" className="text-xs text-red-600 border-red-200 bg-red-50">
                Out of Stock
              </Badge>
            )}
          </div>
          
          <h4 className="font-bold text-foreground line-clamp-2 text-lg group-hover:text-primary transition-colors duration-200" data-testid={`text-name-${product.id}`}>
            {product.name}
          </h4>
          
          <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed" data-testid={`text-description-${product.id}`}>
            {product.shortDescription}
          </p>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <div className="space-y-1">
                <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent" data-testid={`text-price-${product.id}`}>
                  ${price.toFixed(2)}
                </span>
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className="text-xs capitalize px-2 py-0.5">
                    {customerType}
                  </Badge>
                </div>
              </div>
            </div>
            
            <div className="text-xs text-muted-foreground/80 bg-muted/50 p-2 rounded-md" data-testid={`text-wholesale-info-${product.id}`}>
              {customerType === 'retail' ? (
                <span>💼 Wholesale: <strong>${otherPrice.toFixed(2)}</strong> • MOQ: {product.moq} units</span>
              ) : (
                <span>🛒 Retail: <strong>${otherPrice.toFixed(2)}</strong> • MOQ: {product.moq} units</span>
              )}
            </div>
          </div>
          
          <div className="flex gap-2 pt-2">
            <Button 
              className="flex-1 bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary shadow-sm hover:shadow-md transition-all duration-200"
              onClick={handleAddToCart}
              disabled={isLoading || !product.inStock}
              data-testid={`button-add-cart-${product.id}`}
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              {isLoading ? (
                <span className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                  Adding...
                </span>
              ) : (
                'Add to Cart'
              )}
            </Button>
            
            <Button 
              variant="outline" 
              size="icon"
              className="border-primary/20 hover:border-primary hover:bg-primary/5 transition-all duration-200"
              data-testid={`button-wishlist-${product.id}`}
              aria-label="Add to wishlist"
            >
              <Heart className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
