import { useCustomer } from '@/contexts/customer-context';
import { Button } from '@/components/ui/button';

interface CustomerToggleProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function CustomerToggle({ size = 'md', className = '' }: CustomerToggleProps) {
  const { customerType, setCustomerType } = useCustomer();

  const sizeClasses = {
    sm: 'px-3 py-1 text-sm',
    md: 'px-4 py-2 text-sm',
    lg: 'px-6 py-3 text-base',
  };

  return (
    <div className={`customer-toggle bg-secondary rounded-lg p-1 flex ${className}`} data-testid="customer-toggle">
      <Button
        variant={customerType === 'retail' ? 'default' : 'ghost'}
        size="sm"
        className={`${sizeClasses[size]} rounded font-medium`}
        onClick={() => setCustomerType('retail')}
        data-testid="button-retail"
      >
        Retail
      </Button>
      <Button
        variant={customerType === 'wholesale' ? 'default' : 'ghost'}
        size="sm"
        className={`${sizeClasses[size]} rounded font-medium`}
        onClick={() => setCustomerType('wholesale')}
        data-testid="button-wholesale"
      >
        Wholesale
      </Button>
    </div>
  );
}
