import { 
  type Category, 
  type Product, 
  type CartItem, 
  type Inquiry,
  type InsertCategory, 
  type InsertProduct, 
  type InsertCartItem,
  type InsertInquiry 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Products
  getProducts(filters?: { categoryId?: string; featured?: boolean; search?: string }): Promise<Product[]>;
  getProductById(id: string): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Cart
  getCartItems(sessionId: string): Promise<CartItem[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: string, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: string): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;
  
  // Inquiries
  createInquiry(inquiry: InsertInquiry): Promise<Inquiry>;
  getInquiries(): Promise<Inquiry[]>;
}

export class MemStorage implements IStorage {
  private categories: Map<string, Category>;
  private products: Map<string, Product>;
  private cartItems: Map<string, CartItem>;
  private inquiries: Map<string, Inquiry>;

  constructor() {
    this.categories = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.inquiries = new Map();
    
    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Initialize categories
    const sampleCategories: Category[] = [
      {
        id: "cat-1",
        name: "Kitchenware",
        slug: "kitchenware",
        description: "Pots, Pans, Pressure Cookers",
        imageUrl: "https://pixabay.com/get/g6727ac423b10d641731f73b4a627cba3ba979ffde6d17b3b8ff4f6698645d3140b6cbd62215fc6cdb2eff40be7db02d0c370a51141542d262b51b72cd0239028_1280.jpg",
        productCount: 500,
      },
      {
        id: "cat-2",
        name: "Non-stick Cookware",
        slug: "non-stick-cookware",
        description: "Frying Pans, Griddles, Sets",
        imageUrl: "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        productCount: 300,
      },
      {
        id: "cat-3",
        name: "Dinner Sets & Crockery",
        slug: "dinner-sets",
        description: "Plates, Bowls, China Sets",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        productCount: 400,
      },
      {
        id: "cat-4",
        name: "Cutlery",
        slug: "cutlery",
        description: "Knives, Forks, Serving Utensils",
        imageUrl: "https://images.unsplash.com/photo-1618220048045-10a6dbdf83e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        productCount: 250,
      },
      {
        id: "cat-5",
        name: "Household Items",
        slug: "household-items",
        description: "Storage, Cleaning, Accessories",
        imageUrl: "https://pixabay.com/get/gbf7c609cdb0ed428da18e75d553bc3ca8a58022196763d2af631f8b6639dc85cb57fa621ff981a2970cd79f35c8bff7b15422fab589300cf2b4a6a72845baa07_1280.jpg",
        productCount: 600,
      },
      {
        id: "cat-6",
        name: "Plastic Products",
        slug: "plastic-products",
        description: "Containers, Storage, Kitchen Tools",
        imageUrl: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        productCount: 350,
      },
      {
        id: "cat-7",
        name: "Restaurant Ware",
        slug: "restaurant-ware",
        description: "Commercial Equipment, Trays",
        imageUrl: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        productCount: 200,
      },
      {
        id: "cat-8",
        name: "Hotel Ware",
        slug: "hotel-ware",
        description: "Buffet Equipment, Tableware",
        imageUrl: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
        productCount: 180,
      },
    ];

    sampleCategories.forEach(category => {
      this.categories.set(category.id, category);
    });

    // Initialize featured products
    const sampleProducts: Product[] = [
      {
        id: "prod-1",
        name: "Professional Cookware Set",
        slug: "professional-cookware-set",
        description: "12-piece stainless steel cookware set with professional-grade construction",
        shortDescription: "12-piece stainless steel set",
        imageUrl: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        categoryId: "cat-1",
        retailPrice: "299.99",
        wholesalePrice: "249.99",
        moq: 10,
        inStock: true,
        stockQuantity: 100,
        featured: true,
        specifications: JSON.stringify({
          material: "Stainless Steel",
          pieces: 12,
          dishwasherSafe: true,
          warranty: "5 years"
        }),
        createdAt: new Date(),
      },
      {
        id: "prod-2",
        name: "Premium Non-Stick Pan",
        slug: "premium-non-stick-pan",
        description: "12-inch ceramic coated non-stick frying pan with ergonomic handle",
        shortDescription: "12-inch ceramic coating",
        imageUrl: "https://pixabay.com/get/g22f7501dbb4029a48162db7856bb727b9469484e51cd46f3cb991b3a2684f39d72ad5c482b6e8081992d2bf0113a842b13aa93593ccf3a29a25064b1c7300397_1280.jpg",
        categoryId: "cat-2",
        retailPrice: "89.99",
        wholesalePrice: "69.99",
        moq: 20,
        inStock: true,
        stockQuantity: 150,
        featured: true,
        specifications: JSON.stringify({
          material: "Ceramic Non-Stick",
          size: "12 inch",
          handleType: "Ergonomic",
          warranty: "2 years"
        }),
        createdAt: new Date(),
      },
      {
        id: "prod-3",
        name: "Porcelain Dinner Set",
        slug: "porcelain-dinner-set",
        description: "24-piece elegant porcelain dinner set perfect for fine dining",
        shortDescription: "24-piece elegant collection",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        categoryId: "cat-3",
        retailPrice: "199.99",
        wholesalePrice: "159.99",
        moq: 6,
        inStock: true,
        stockQuantity: 80,
        featured: true,
        specifications: JSON.stringify({
          material: "Fine Porcelain",
          pieces: 24,
          microwaveSafe: true,
          dishwasherSafe: true,
          warranty: "3 years"
        }),
        createdAt: new Date(),
      },
      {
        id: "prod-4",
        name: "Chef Knife Set",
        slug: "chef-knife-set",
        description: "6-piece German steel professional chef knife set with wooden block",
        shortDescription: "6-piece German steel",
        imageUrl: "https://images.unsplash.com/photo-1618220048045-10a6dbdf83e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        categoryId: "cat-4",
        retailPrice: "149.99",
        wholesalePrice: "119.99",
        moq: 12,
        inStock: true,
        stockQuantity: 60,
        featured: true,
        specifications: JSON.stringify({
          material: "German Steel",
          pieces: 6,
          blockIncluded: true,
          warranty: "Lifetime"
        }),
        createdAt: new Date(),
      },
    ];

    sampleProducts.forEach(product => {
      this.products.set(product.id, product);
    });
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(cat => cat.slug === slug);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const category: Category = { 
      ...insertCategory, 
      id, 
      productCount: 0,
      description: insertCategory.description ?? null,
      imageUrl: insertCategory.imageUrl ?? null
    };
    this.categories.set(id, category);
    return category;
  }

  async getProducts(filters?: { categoryId?: string; featured?: boolean; search?: string }): Promise<Product[]> {
    let products = Array.from(this.products.values());
    
    if (filters?.categoryId) {
      products = products.filter(p => p.categoryId === filters.categoryId);
    }
    
    if (filters?.featured !== undefined) {
      products = products.filter(p => p.featured === filters.featured);
    }
    
    if (filters?.search) {
      const searchTerm = filters.search.toLowerCase();
      products = products.filter(p => 
        p.name.toLowerCase().includes(searchTerm) ||
        p.description?.toLowerCase().includes(searchTerm)
      );
    }
    
    return products;
  }

  async getProductById(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(p => p.slug === slug);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { 
      ...insertProduct, 
      id, 
      createdAt: new Date(),
      description: insertProduct.description ?? null,
      shortDescription: insertProduct.shortDescription ?? null,
      imageUrl: insertProduct.imageUrl ?? null,
      categoryId: insertProduct.categoryId ?? null,
      featured: insertProduct.featured ?? null,
      inStock: insertProduct.inStock ?? null,
      stockQuantity: insertProduct.stockQuantity ?? null,
      specifications: insertProduct.specifications ?? null,
      moq: insertProduct.moq ?? null
    };
    this.products.set(id, product);
    return product;
  }

  async getCartItems(sessionId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(item => item.sessionId === sessionId);
  }

  async addToCart(item: InsertCartItem): Promise<CartItem> {
    const id = randomUUID();
    const cartItem: CartItem = { ...item, id };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: string, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (item) {
      item.quantity = quantity;
      this.cartItems.set(id, item);
      return item;
    }
    return undefined;
  }

  async removeFromCart(id: string): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<boolean> {
    const items = await this.getCartItems(sessionId);
    items.forEach(item => this.cartItems.delete(item.id));
    return true;
  }

  async createInquiry(insertInquiry: InsertInquiry): Promise<Inquiry> {
    const id = randomUUID();
    const inquiry: Inquiry = { 
      ...insertInquiry, 
      id, 
      createdAt: new Date(),
      phone: insertInquiry.phone ?? null,
      company: insertInquiry.company ?? null
    };
    this.inquiries.set(id, inquiry);
    return inquiry;
  }

  async getInquiries(): Promise<Inquiry[]> {
    return Array.from(this.inquiries.values());
  }
}

export const storage = new MemStorage();
