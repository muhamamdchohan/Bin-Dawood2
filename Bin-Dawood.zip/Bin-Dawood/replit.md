# ShopSwift - E-commerce Platform

## Overview

ShopSwift is a modern full-stack e-commerce platform designed for Bin Dawood, a wholesale and retail supplier of kitchenware, household items, and restaurant supplies. The platform supports dual pricing systems (wholesale/retail), comprehensive product catalog management, shopping cart functionality, and customer inquiry systems. Built with TypeScript, React, and Express.js, it provides a seamless experience for both retail customers and wholesale buyers across multiple product categories including kitchenware, cookware, dinner sets, cutlery, and restaurant supplies.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client uses React 18 with TypeScript in a single-page application structure powered by Vite. The UI is built with Radix UI primitives and styled using Tailwind CSS with the shadcn/ui component library. State management is handled through React Context API for customer type and cart state, with React Query managing server state and API calls. The routing system uses Wouter for lightweight client-side navigation.

### Backend Architecture
The server is built on Express.js with TypeScript, implementing a RESTful API design. The storage layer uses an abstraction pattern with both database and in-memory implementations, allowing the system to fall back gracefully when no database is available. API routes are organized by resource type (categories, products, cart, inquiries) with consistent error handling and response formatting.

### Data Storage Solutions
The application is configured to use PostgreSQL as the primary database with Drizzle ORM for type-safe database operations. Database migrations are managed through Drizzle Kit. When a database connection is unavailable, the system falls back to an in-memory storage implementation, ensuring the application remains functional for development and testing.

### Authentication and Authorization
Currently implements session-based cart management using browser localStorage for session persistence. The system is designed to accommodate future authentication implementation with customer type-based access control for wholesale vs retail pricing and features.

### Component Architecture
The UI follows a modular component structure with reusable components for products, categories, and cart functionality. Customer type context provides global state for pricing display and cart behavior. The cart system supports quantity management, price calculations, and session persistence across browser sessions.

## External Dependencies

### UI and Styling
- **Radix UI**: Complete set of unstyled, accessible UI primitives for dialogs, forms, navigation, and interactive elements
- **Tailwind CSS**: Utility-first CSS framework for responsive design and styling
- **shadcn/ui**: Pre-built component library built on Radix UI and Tailwind CSS
- **Lucide React**: Icon library providing consistent iconography throughout the application

### Development and Build Tools
- **Vite**: Build tool and development server with hot module replacement
- **TypeScript**: Type safety and enhanced developer experience
- **ESBuild**: Fast bundler for production builds
- **PostCSS**: CSS processing with Tailwind CSS integration

### Database and ORM
- **Drizzle ORM**: Type-safe SQL query builder and schema management
- **Neon Database**: Serverless PostgreSQL database with connection pooling
- **Drizzle Kit**: Database migration and schema management tools

### State Management and API
- **React Query**: Server state management, caching, and synchronization
- **React Hook Form**: Form validation and state management with Zod schema validation
- **Zod**: Runtime type validation for form inputs and API data

### Routing and Navigation
- **Wouter**: Lightweight client-side routing library for React applications

### Production Considerations
The application is configured for deployment with environment-based configuration, production build optimization, and graceful fallbacks for missing services. The storage abstraction allows deployment flexibility, working with or without database connectivity.